ALTER TABLE [#__users] ADD [requireReset] [smallint] NULL DEFAULT 0;
